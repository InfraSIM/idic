# -*- coding: utf-8 -*-
__version__ = '0.9.0'
__description__ = 'Helpers, syntaxic sugar and Swagger documentation for Flask-Restful'
