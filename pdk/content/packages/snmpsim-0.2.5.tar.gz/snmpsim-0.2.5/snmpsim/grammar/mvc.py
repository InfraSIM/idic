from snmpsim.grammar import dump

class MvcGrammar(dump.DumpGrammar): pass
