from twisted.internet import defer
from pysnmp.entity.rfc3413 import cmdgen

def _cbFun(snmpEngine, sendRequestHandle, errorIndication,
           errorStatus, errorIndex, varBinds, cbCtx):
    df = cbCtx['df']
    df.callback(
        (snmpEngine, errorIndication, errorStatus, errorIndex, varBinds)
    )
    # Callback function may return another deferred to indicate
    # it wishes to continue MIB walk.
    if isinstance(df.result, defer.Deferred):
        cbCtx['df'] = df.result
        return 1  # continue walking

class AbstractCommandGenerator:
    commandGenerator = None

    def sendVarBinds(self, snmpEngine, targetName,
                     contextEngineId, contextName, varBinds):
        df = defer.Deferred()
        self.commandGenerator.sendVarBinds(
            snmpEngine,
            targetName,
            contextEngineId,
            contextName,
            varBinds,
            _cbFun,
            { 'df': df }  # anonymous dictionary used for cbCtx
        )
        return df
            
class GetCommandGenerator(AbstractCommandGenerator):
    commandGenerator = cmdgen.GetCommandGenerator()

class SetCommandGenerator(AbstractCommandGenerator):
    commandGenerator = cmdgen.SetCommandGenerator()

class NextCommandGeneratorSingleRun(AbstractCommandGenerator):
    commandGenerator = cmdgen.NextCommandGeneratorSingleRun()

class NextCommandGenerator(AbstractCommandGenerator):
    commandGenerator = cmdgen.NextCommandGenerator()

class AbstractBulkCommandGenerator:
    commandGenerator = None

    def sendVarBinds(
        self,
        snmpEngine,
        targetName,
        contextEngineId,
        contextName,
        nonRepeaters,
        maxRepetitions,
        varBinds
        ):
        df = defer.Deferred()
        self.commandGenerator.sendVarBinds(
            snmpEngine,
            targetName,
            contextEngineId,
            contextName,
            nonRepeaters,
            maxRepetitions,
            varBinds,
            _cbFun,
            { 'df': df }  # anonymous dictionary used for cbCtx
            )
        return df

class BulkCommandGeneratorSingleRun(AbstractBulkCommandGenerator):
    commandGenerator = cmdgen.BulkCommandGeneratorSingleRun()

class BulkCommandGenerator(AbstractBulkCommandGenerator):
    commandGenerator = cmdgen.BulkCommandGenerator()
        
#
# Obsolete, compatibility interfaces.
#

def __sendReqCbFun(response, outerDf):
    ( snmpEngine,
      errorIndication,
      errorStatus,
      errorIndex,
      varBinds) = response
    outerDf.callback((errorIndication, errorStatus, errorIndex, varBinds))
    # Callback function may return another deferred to indicate
    # it wishes to continue MIB walk.
    if isinstance(outerDf.result, defer.Deferred):
        innerDf = defer.Deferred()
        innerDf.addCallback(__sendReqCbFun, outerDf.result)
        return innerDf

def _sendReq(self,
             snmpEngine,
             targetName,
             varBinds,
             contextEngineId=None,
             contextName=''):
    innerDf = self.sendVarBinds(snmpEngine,
                                targetName,
                                contextEngineId,
                                contextName,
                                varBinds)
    outerDf = defer.Deferred()
    innerDf.addCallback(__sendReqCbFun, outerDf)
    return outerDf

def _sendBulkReq(self,
                 snmpEngine,
                 targetName,
                 nonRepeaters,
                 maxRepetitions,
                 varBinds,
                 contextEngineId=None,
                 contextName=''):
    innerDf = self.sendVarBinds(snmpEngine,
                                targetName,
                                contextEngineId,
                                contextName,
                                nonRepeaters,
                                maxRepetitions,
                                varBinds)
    outerDf = defer.Deferred()
    innerDf.addCallback(__sendReqCbFun, outerDf)
    return outerDf

# install compatibility wrappers
GetCommandGenerator.sendReq = _sendReq
SetCommandGenerator.sendReq = _sendReq
NextCommandGenerator.sendReq = _sendReq
NextCommandGeneratorSingleRun.sendReq = _sendReq
BulkCommandGenerator.sendReq = _sendBulkReq
BulkCommandGeneratorSingleRun.sendReq = _sendBulkReq
