#
# Copyright (C) 2014, Zebra Technologies
# Authors: Matt Hooks <me@matthooks.com>
#          Zachary Lorusso <zlorusso@gmail.com>
# Modified by Ilya Etingof <ilya@snmplabs.com>
#
# Redistribution and use in source and binary forms, with or without 
# modification, are permitted provided that the following conditions are met:
#
# * Redistributions of source code must retain the above copyright notice,
#   this list of conditions and the following disclaimer.
#
# * Redistributions in binary form must reproduce the above copyright
#   notice, this list of conditions and the following disclaimer in the 
#   documentation and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
# THE POSSIBILITY OF SUCH DAMAGE.
#
from pysnmp.entity.rfc3413 import cmdgen
from pyasn1.compat.octets import null
from pysnmp.proto.api import v2c
try:
    import asyncio
except ImportError:
    import trollius as asyncio

getNextVarBinds = cmdgen.getNextVarBinds

class AbstractCommandGenerator:
    commandGenerator = None

    def _cbFunWithFuture(self, snmpEngine, sendRequestHandle, errorIndication,
                         errorStatus, errorIndex, varBinds, future):
        if future.cancelled():
            return
        future.set_result(
            (snmpEngine, errorIndication, errorStatus, errorIndex, varBinds)
        )

    def sendVarBinds(self, snmpEngine, targetName,
                     contextEngineId, contextName, varBinds):
        future = asyncio.Future()
        self.commandGenerator.sendVarBinds(
            snmpEngine,
            targetName,
            contextEngineId,
            contextName,
            varBinds,
            self._cbFunWithFuture,
            future
        )
        return future
            
class GetCommandGenerator(AbstractCommandGenerator):
    commandGenerator = cmdgen.GetCommandGenerator()

class SetCommandGenerator(AbstractCommandGenerator):
    commandGenerator = cmdgen.SetCommandGenerator()

class NextCommandGenerator(AbstractCommandGenerator):
    commandGenerator = cmdgen.NextCommandGenerator()

class BulkCommandGenerator(AbstractCommandGenerator):
    commandGenerator = cmdgen.BulkCommandGenerator()

    def sendVarBinds(self, snmpEngine, targetName,
                     contextEngineId, contextName,
                     nonRepeaters, maxRepetitions, varBinds):
        future = asyncio.Future()
        self.commandGenerator.sendVarBinds(
            snmpEngine,
            targetName,
            contextEngineId,
            contextName,
            nonRepeaters,
            maxRepetitions,
            varBinds,
            self._cbFunWithFuture,
            future
        )
        return future
