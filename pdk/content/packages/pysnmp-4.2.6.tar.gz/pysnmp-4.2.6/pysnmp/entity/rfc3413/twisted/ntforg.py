from twisted.internet import defer
from pysnmp.entity.rfc3413 import ntforg
from pyasn1.compat.octets import null

def __cbFun(snmpEngine, sendRequestHandle, errorIndication,
           errorStatus, errorIndex, varBinds, cbCtx):
    cbCtx.callback(
        (snmpEngine, errorIndication, errorStatus, errorIndex, varBinds)
    )

class NotificationOriginator:
    def __init__(self, snmpContext=None):
        self.snmpContext = snmpContext  # this is deprecated
        self.notificationOriginator = ntforg.NotificationOriginator()

    def sendVarBinds(self,
                     snmpEngine,
                     notificationTarget,
                     snmpContext,
                     contextName,
                     notificationName,
                     instanceIndex,
                     additionalVarBinds=()):
        df = defer.Deferred()
        self.notificationOriginator.sendVarBinds(
            snmpEngine,
            notificationTarget,
            snmpContext,
            contextName,
            notificationName,
            instanceIndex,
            additionalVarBinds,
            __cbFun,
            df
        )
        return df

#
# Obsolete, compatibility interfaces.
#

def __sendReqCbFun(response, outerDf):
    ( snmpEngine,
      errorIndication,
      errorStatus,
      errorIndex,
      varBinds) = response
    outerDf.callback((errorIndication, errorStatus, errorIndex, varBinds))
    # Callback function may return another deferred to indicate
    # it wishes to continue MIB walk.
    if isinstance(outerDf.result, defer.Deferred):
        innerDf = defer.Deferred()
        innerDf.addCallback(__sendReqCbFun, outerDf.result)
        return innerDf

def _sendNotification(self,
                      snmpEngine,
                      notificationTarget,
                      notificationName,
                      additionalVarBinds=None,
                      contextName=null):

    innerDf = self.sendVarBinds(snmpEngine,
                                notificationTarget,
                                self.snmpContext,
                                contextName,
                                notificationName,
                                None,
                                additionalVarBinds)
    outerDf = defer.Deferred()
    innerDf.addCallback(__sendReqCbFun, outerDf)
    return outerDf

# install compatibility wrappers
NotificationOriginator.sendNotification = _sendNotification
