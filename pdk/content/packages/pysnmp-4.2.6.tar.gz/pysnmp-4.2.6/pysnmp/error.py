class PySnmpError(Exception): pass
